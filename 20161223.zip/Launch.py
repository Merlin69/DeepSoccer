# -*- coding: utf-8 -*-
import time
import Params
import tensorflow as tf
import csv
import math

class Launch:
    def __init__(self, data, model, algogen=None):
        
        self.data = data
        self.model = model
        self.algogen = algogen
        self.tf_operations = [] 
        self.session = None
        
    def Go(self): 
        
        for key in self.model.features_data():
            self.tf_operations.append(tf.assign(self.model.current_slice[key], self.model.ph_current_slice[key],
                                                validate_shape=False))

        self.model.define_logloss(regularized=False, trainable=False)
        self.model.define_logloss(regularized=True, trainable=True)
        self.model.finish_init()
        
        self.model.set_params(Params.paramStd)
        ll_mean = 0.
        lls_mean = 0.
        with open('hey.csv', 'w') as csvfile:
            spamwriter = csv.writer(csvfile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
            for i in range(self.data.slices.nb_slices):
                t = time.time()
                self.model.reset()
                self.set_current_slice(index=i, label='train')
                self.model.train('rll_res', Params.NB_LOOPS)
                self.set_current_slice(index=i, label='test')
                ll = self.model.get_cost('ll_res')
                prediction = self.model.run(self.model.prediction['res'])
                keys = ['res', 'odds']
                datas = {}
                for key in keys:
                    datas[key] = self.get_py_slice(i, 'test', key)
                    if len(datas[key]) != len(prediction):
                        print('ERROR')
                for j in range(len(prediction)):
                    to_write = list(prediction[j]) + datas['odds'][j] + datas['res'][j]
                    print(to_write)
                    spamwriter.writerow(to_write)
                ll_mean += ll
                lls_mean += ll**2
                print(i, ll, '(time: ' + str(time.time() - t) + ')')
        
        print('Mean: ', ll_mean/self.data.slices.nb_slices)
        print('Std_Dev: ', math.sqrt(lls_mean/self.data.slices.nb_slices - (ll_mean/self.data.slices.nb_slices)**2))
        
        
        self.model.close()

    def set_current_slice(self, index=None, label=None): 
        feed_dict = {}
        for key in self.model.features_data():
            s = self.get_py_slice(index,label,key)
            feed_dict[self.model.ph_current_slice[key]] = s
        self.model.session.run(self.tf_operations, feed_dict=feed_dict)
        

    def get_py_slice(self, index, label, key):
        return self.data.datas[key][self.data.slices.slices[index][label]['left']:self.data.slices.slices[index][label]['right']]


