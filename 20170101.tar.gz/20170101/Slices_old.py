import tensorflow as tf
from random import sample


class Slices:
    def __init__(self, data):    
        self.slices = []
        self.data = data
        self.slices = {}

    def init_slices(self, group):
        self.slices[group] = {'train': [], 'test': []}

        if group == 'Lpack':
            current_journee = -1
            current_nb_slice = -1
            nb_matchs = 0
            current_slice_test = {'left': 0, 'right': 0}
            current_slice_train = {'left': 0, 'right': 0}
            for row in self.data.py_datas:
                if row:
                    [ID, saison, Date, journee, id1, id2, score1, score2, Spectateur, JourDeLaSemaine,
                     FTR, FTHG, FTAG, BbMxH, BbMxD, BbMxA, BbAvH, BbAvD, BbAvA, HTHG, HTAG, HTR, HS, AS, HST, AST,
                     HC, AC] = row
                    if current_journee != journee and self.nb_matchs > 3800:
                        current_journee = journee
                        current_slice_test['right'] = self.nb_matchs + 1
                        current_slice_test['name'] = 'test_' + str(current_nb_slice)
                        current_slice_train['right'] = self.nb_matchs + 1
                        current_slice_train['name'] = 'train_' + str(current_nb_slice+1)
                        current_nb_slice += 1
                        if current_nb_slice > 0:
                            self.slices[group]['test'].append(copy.copy(current_slice_test))
                        self.slices[group]['train'].append(copy.copy(current_slice_train))
                        current_slice_test['left'] = self.nb_matchs + 1
                    nb_matchs += 1
            self.slices.check_slices(group)

        elif group == 'Shuffle':
            p = 0.5
            self.slices[group]['test'] = [{'left': 0, 'right': int(self.data.nb_matchs * p)}]
            self.slices[group]['train'] = [{'left': int(self.data.nb_matchs * p)+1, 'right': self.data.nb_matchs}]

        else:
            print('Unkown type ' + type)

    def check_slices(self, group):
        self.nb_slices = min(len(self.slices[group]['test']), len(self.slices[group]['train']))
        for i in range(self.nb_slices):
            if self.slices[group]['train'][i]['right'] <= self.slices[group]['test'][i]['left'] 
                        or self.slices[group]['train'][i]['left'] >= self.slices[group]['test'][i]['right']:
                if self.slices[group]['train'][i]['name'] != 'train_'+str(i) or self.slices[group]['test'][i]['name'] != 'test_'+str(i):
                    print('slice error')
            else:
                print('overlapping train and test')
                
    def get_slice(self, group, index=0, label=None):
        if group not in self.slices:
            self.init_slices(group)
        slices = self.slices[group]
        if label == None:
            if len(list(slices.keys())) == 1:
                label =  list(slices.keys())[0]
            else:
                print('label error')
        if group in ['LPack']:
            source = self.data.datas
        else:
            source = self.data.shuffled_datas
        s = {}
        for key in self.data.datas:
            s[key] = source[key][slices[index][label]['left']:slices[index][label]['right']]
        return s


   