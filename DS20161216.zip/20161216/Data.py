import csv
import ToolBox
import copy
import Slices
import Params

ALL_FEATURES = ['saison', 'team_h', 'team_a', 'res', 'score_h', 'score_a', 'journee',
                'odd_win_h', 'odd_tie', 'odd_los_h', 'odds']


class Data:
    def __init__(self, filename, features=ALL_FEATURES, remove_features=[], typeslices='overtime'):

        self.slices = Slices.Slices()
        self.filename = filename
        self.features = [x for x in features if x not in remove_features]
        
        self.country_to_id = {}
        self.id_to_country = []
        
        self.datas = {}
        for key in features:
            self.datas[key] = []
        self.nb_matchs = 0

        self.set_slices_and_append_matches()
        
    def set_slices_and_append_matches(self, p=None): 
    
        slices_train = []
        slices_test = []
        with open(self.filename) as csvfile:
            spamreader = csv.reader(csvfile, delimiter=',')
            spamreader.__next__() # ?? Essayer sans
            current_journee = -1
            current_nb_slice = -1
            current_slice_test = {'left': 0, 'right': 0}
            current_slice_train = {'left': 0, 'right': 0}
            for row in spamreader:
                if row:
                    [ID, saison, Date, journee, id1, id2, score1, score2, Spectateur, JourDeLaSemaine,
                     FTR, FTHG, FTAG, BbMxH, BbMxD, BbMxA, BbAvH, BbAvD, BbAvA, HTHG, HTAG, HTR, HS, AS, HST, AST,
                     HC, AC] = row
                    if current_journee != journee and self.nb_matchs > 3800:
                        current_journee = journee
                        current_slice_test['right'] = self.nb_matchs + 1
                        current_slice_test['name'] = 'test_' + str(current_nb_slice)
                        current_slice_train['right'] = self.nb_matchs + 1
                        current_slice_train['name'] = 'train_' + str(current_nb_slice+1)
                        current_nb_slice += 1
                        if current_nb_slice > 0:
                            slices_test.append(copy.copy(current_slice_test))
                        slices_train.append(copy.copy(current_slice_train))
                        current_slice_test['left'] = self.nb_matchs + 1
                    self.nb_matchs += 1
                    self.append_match(int(id1), int(id2), int(score1),
                                      int(score2), int(saison) - 2003, int(journee), BbMxH, BbMxD, BbMxA)
        
        self.slices.set_slices(slices_train,slices_test)

    def append_match(self, id1, id2, score1, score2, saison, journee, win_odd, tie_odd, los_odd):
        if win_odd == '':
            win_odd = -1.
            tie_odd = -1.
            los_odd = -1.
        self.datas['odd_win_h'].append([float(win_odd)])
        self.datas['odd_tie'].append([float(tie_odd)])
        self.datas['odd_los_h'].append([float(los_odd)])
        self.datas['odds'].append([float(win_odd), float(tie_odd), float(los_odd)])
        self.datas['saison'].append(ToolBox.make_vector(saison, Params.data2_nb_saisons))
        self.datas['team_h'].append(ToolBox.make_vector(id1, Params.data2_nb_teams))
        self.datas['team_a'].append(ToolBox.make_vector(id2, Params.data2_nb_teams))
        score_team_h = min(int(score1), 9)
        score_team_a = min(int(score2), 9)
        self.datas['score_h'].append(ToolBox.make_vector(score_team_h, 10))
        self.datas['score_a'].append(ToolBox.make_vector(score_team_a, 10))
        self.datas['res'].append(ToolBox.result_vect(int(score1) - int(score2)))
        self.datas['journee'].append(ToolBox.make_vector(journee + Params.data2_nb_max_journee*saison, Params.data2_nb_journee))

    def get_elos(self, countries=None, times='all'):
        if countries is None:
            countries = [self.id_to_country[i] for i in range(Params.data2_nb_teams)]
        else:
            countries = map(ToolBox.format_name, countries)
        if times == 'all':
            times = range(Params.data2_nb_saisons)
        elif times == 'last':
            times = [Params.data2_nb_saisons - 1]
        elos = {}
        for country in countries:
            elos[country] = [200*self.elo[self.country_to_id[country]][t] for t in times]
        return elos

        
             #seed = random.randint(0, MAX_SEED)
        #for key in self.features:
        #    self.tf_datas[key] = tf.constant(self.datas[key], dtype=DATA_TYPE)  # Essayer avec variable trainable=False
        #    self.tf_shuffled_datas[key] = tf.random_shuffle(self.tf_datas[key], seed=seed)

#    def add_slices(self, p=None):
#        if p is not None:
#            slices = [{'left': 0, 'right': int(self.nb_matchs * p), 'name': 'train', 'shuffled': True},
#                      {'left': int(self.nb_matchs * p), 'right': -1, 'name': 'test', 'shuffled': True}]
#            map(self.create_tf_slice, slices)
#        if p is None:
#            for s in self.timeslices:
#                self.create_tf_slice(s)
#        print('Slices created. ' + str(ToolBox.nb_tf_op()) + ' nodes in tf.Graph')
#
#    def create_tf_slice(self, s):
#        self.tf_slices[s['name']] = {}
#        for key in self.features:
#            if s['shuffled']:
#                shuffled_slice = tf.slice(self.tf_shuffled_datas[key], [s['left'], 0], [s['right'], -1])
#                self.tf_slices[s['name']][key] = tf.Variable(0., validate_shape=False,
#                                                             dtype=DATA_TYPE, trainable=False, collections=[])
#                self.shuffle.append(tf.assign(self.tf_slices[s['name']][key], shuffled_slice, validate_shape=False))
#            else:
#                value = tf.slice(self.tf_datas[key], [s['left'], 0], [s['right'], -1])
#                self.tf_slices[s['name']][key] = value # tf.Variable(value, dtype=DATA_TYPE, trainable=False, collections=[])