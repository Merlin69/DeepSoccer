import Data
import Elostd
import Launch
import Params
import sys

print(sys.version)


data = Data.Data('Datas/' + Params.FILE + '.txt', typeslices = 'overtime')

model = Elostd.Elostd() 

launch = Launch.Launch(data,model)

launch.Go()

