import tensorflow as tf


class Slices:
    def __init__(self):    
        self.slices = []

    def set_slices(self, slices_train, slices_test):
        self.nb_slices = min(len(slices_train), len(slices_test))
        for i in range(self.nb_slices):
            if slices_train[i]['right'] <= slices_test[i]['left'] or slices_train[i]['left'] >= slices_test[i]['right']:
                if slices_train[i]['name'] == 'train_'+str(i) and slices_test[i]['name'] == 'test_'+str(i):
                    self.slices.append({'train': slices_train[i], 'test': slices_test[i]})
                else:
                    print('slice error')
            else:
                print('overlapping train and test')
                
        print('Slices created: ', self.nb_slices)

   