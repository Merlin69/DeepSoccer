import tensorflow as tf
import ToolBox
import Model as M
import math
import Costs

PARAMS = []
LIN_PARAMS = []


class BookMaker(M.Model):
    def __init__(self, data):
        super(BookMaker, self).__init__(data)

        self.param = {}
        for key in PARAMS:
            self.param[key] = tf.placeholder(tf.float32)

        # Define the model

        for key in self.data.tf_slices:
            s = self.data.tf_slices[key]
            p_win = 1. / tf.squeeze(s['odd_win_h'], [1])
            p_tie = 1. / tf.squeeze(s['odd_tie'], [1])
            p_los = 1. / tf.squeeze(s['odd_los_h'], [1])
            self.res[key] = tf.pack([p_win, p_tie, p_los], axis=1)

        # Define the costs
        regulizer = {}
        self.regulizer = Costs.Cost(self, 'reg', costs=regulizer)
