import tensorflow as tf


class Slices:
    def __init__(self, data, type):
        self.data = data
        self.type = type
        if type == 'overtime':
            self.slices = []
            slices_tr = data.timeslices_tr
            slices_te = data.timeslices_te
            self.nb_slices = min(len(slices_tr), len(slices_te))
            for i in range(self.nb_slices):
                if slices_tr[i]['right'] <= slices_te[i]['left'] or slices_tr[i]['left'] >= slices_te[i]['right']:
                    if slices_tr[i]['name'] == 'train_'+str(i) and slices_te[i]['name'] == 'test_'+str(i):
                        self.slices.append({'train': slices_tr[i], 'test': slices_te[i]})
                    else:
                        print('slice error')
                else:
                    print('overlapping train and test')

    def add_to_model(self, model):
        if self.type == 'overtime':
            if not model.assign_slice:
                for key in model.features_data():
                    model.assign_slice.append(tf.assign(model.current_slice[key], model.ph_current_slice[key],
                                                        validate_shape=False))

    def set_current_slice(self, model, index=None, label=None):
        if self.type == 'overtime':
            feed_dict = {}
            for key in model.features_data():
                s = self.get_py_slice(index,label,key)
                feed_dict[model.ph_current_slice[key]] = s
            model.session.run(model.assign_slice, feed_dict=feed_dict)

    def get_py_slice(self, index, label, key):
        return self.data.datas[key][self.slices[index][label]['left']:self.slices[index][label]['right']]


