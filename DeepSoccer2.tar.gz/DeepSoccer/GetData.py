import csv
import datetime
import ToolBox
import random
import tensorflow as tf
import sys
import copy

ALL_FEATURES = ['saison', 'team_h', 'team_a', 'res', 'score_h', 'score_a', 'journee',
                'odd_win_h', 'odd_tie', 'odd_los_h', 'odds']
DATA_TYPE = tf.float32
MAX_SEED = int(1e16)


class Data:
    def __init__(self, filename, features=ALL_FEATURES, remove_features=[]):

        self.filename = filename
        self.features = [x for x in features if x not in remove_features]

        self.country_to_id = {}
        self.id_to_country = []
        self.nb_teams = 159
        self.nb_saisons = 14
        self.max_journee = 38
        self.nb_journee = (self.nb_saisons + 1) * self.max_journee
        self.nb_matchs = 0
        self.timeslices_tr = []
        self.timeslices_te = []

        self.datas = {}
        for key in features:
            self.datas[key] = []

        self.costs = []

        self.tf_shuffled_datas = {}
        self.tf_datas = {}
        self.tf_slices = {}
        self.shuffle = []

        with open(self.filename) as csvfile:
            spamreader = csv.reader(csvfile, delimiter=',')
            spamreader.__next__()
            current_journee = -1
            current_indice = -1
            current_slicete = {'left': 0, 'right': 0}
            current_slicetr = {'left': 0, 'right': 0}
            for row in spamreader:
                if row:
                    [ID, saison, Date, journee, id1, id2, score1, score2, Spectateur, JourDeLaSemaine,
                     FTR, FTHG, FTAG, BbMxH, BbMxD, BbMxA, BbAvH, BbAvD, BbAvA, HTHG, HTAG, HTR, HS, AS, HST, AST,
                     HC, AC] = row
                    if current_journee != journee and self.nb_matchs > 3800:
                        current_journee = journee
                        current_slicete['right'] = self.nb_matchs + 1
                        current_slicete['name'] = 'test_' + str(current_indice)
                        current_slicetr['right'] = self.nb_matchs + 1
                        current_slicetr['name'] = 'train_' + str(current_indice+1)
                        current_indice += 1
                        if current_indice > 0:
                            self.timeslices_te.append(copy.copy(current_slicete))
                        self.timeslices_tr.append(copy.copy(current_slicetr))
                        current_slicete['left'] = self.nb_matchs + 1
                    self.nb_matchs += 1
                    self.append_match(self.datas, int(id1), int(id2), int(score1),
                                      int(score2), int(saison) - 2003, int(journee), BbMxH, BbMxD, BbMxA)
        #seed = random.randint(0, MAX_SEED)
        #for key in self.features:
        #    self.tf_datas[key] = tf.constant(self.datas[key], dtype=DATA_TYPE)  # Essayer avec variable trainable=False
        #    self.tf_shuffled_datas[key] = tf.random_shuffle(self.tf_datas[key], seed=seed)

    def add_slices(self, p=None):
        if p is not None:
            slices = [{'left': 0, 'right': int(self.nb_matchs * p), 'name': 'train', 'shuffled': True},
                      {'left': int(self.nb_matchs * p), 'right': -1, 'name': 'test', 'shuffled': True}]
            map(self.create_tf_slice, slices)
        if p is None:
            for s in self.timeslices:
                self.create_tf_slice(s)
        print('Slices created. ' + str(ToolBox.nb_tf_op()) + ' nodes in tf.Graph')

    def create_tf_slice(self, s):
        self.tf_slices[s['name']] = {}
        for key in self.features:
            if s['shuffled']:
                shuffled_slice = tf.slice(self.tf_shuffled_datas[key], [s['left'], 0], [s['right'], -1])
                self.tf_slices[s['name']][key] = tf.Variable(0., validate_shape=False,
                                                             dtype=DATA_TYPE, trainable=False, collections=[])
                self.shuffle.append(tf.assign(self.tf_slices[s['name']][key], shuffled_slice, validate_shape=False))
            else:
                value = tf.slice(self.tf_datas[key], [s['left'], 0], [s['right'], -1])
                self.tf_slices[s['name']][key] = value # tf.Variable(value, dtype=DATA_TYPE, trainable=False, collections=[])

    def append_match(self, proxy, id1, id2, score1, score2, saison, journee, win_odd, tie_odd, los_odd):
        if win_odd == '':
            win_odd = -1.
            tie_odd = -1.
            los_odd = -1.
        proxy['odd_win_h'].append([float(win_odd)])
        proxy['odd_tie'].append([float(tie_odd)])
        proxy['odd_los_h'].append([float(los_odd)])
        proxy['odds'].append([float(win_odd), float(tie_odd), float(los_odd)])
        proxy['saison'].append(ToolBox.make_vector(saison, self.nb_saisons))
        proxy['team_h'].append(ToolBox.make_vector(id1, self.nb_teams))
        proxy['team_a'].append(ToolBox.make_vector(id2, self.nb_teams))
        score_team_h = min(int(score1), 9)
        score_team_a = min(int(score2), 9)
        proxy['score_h'].append(ToolBox.make_vector(score_team_h, 10))
        proxy['score_a'].append(ToolBox.make_vector(score_team_a, 10))
        proxy['res'].append(ToolBox.result_vect(int(score1) - int(score2)))
        proxy['journee'].append(ToolBox.make_vector(journee + self.max_journee*saison, self.nb_journee))

    def get_elos(self, countries=None, times='all'):
        if countries is None:
            countries = [self.id_to_country[i] for i in range(self.nb_teams)]
        else:
            countries = map(ToolBox.format_name, countries)
        if times == 'all':
            times = range(self.nb_saisons)
        elif times == 'last':
            times = [self.nb_saisons - 1]
        elos = {}
        for country in countries:
            elos[country] = [200*self.elo[self.country_to_id[country]][t] for t in times]
        return elos
