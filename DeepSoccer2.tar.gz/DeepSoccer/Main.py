import GetData
import Elostd
import Elosplit
import time
import sys
import MetaOpti
import csv
from scipy.optimize import differential_evolution
import numpy as np
import math
import random
import tensorflow as tf
import ToolBox
import copy
import Costs
import Slices


import sys

print(sys.version)
paramStd = {'metaparamj2': 7.596735999999996,
            'metaparamj1': -9.9995,
            'metaparamj0': -0.6004999999999996,
            'metaparam2': 1.809571999999999,
            'metaparam1': -10.2545,
            'metaparam0': -11.799499999999998,
            'bais_ext': 0.5396204199999999,
            'draw_elo': -0.4084012199999998,
            }
FILE = 'ResultWithOdds2'
NB_LOOPS = 60

data = GetData.Data('Datas/' + FILE + '.txt')
overtime = Slices.Slices(data, 'overtime')

print('Slices created: ', overtime.nb_slices)

model = Elostd.Elostd(data)
overtime.add_to_model(model)
model.define_logloss(regularized=False, trainable=False)
model.define_logloss(regularized=True, trainable=True)
model.finish_init()

model.set_params(paramStd)
ll_mean = 0.
lls_mean = 0.
with open('hey.csv', 'w') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter=',', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    for i in range(overtime.nb_slices):
        t = time.time()
        model.reset()
        overtime.set_current_slice(model, index=i, label='train')
        model.train('rll_res', NB_LOOPS)
        overtime.set_current_slice(model, index=i, label='test')
        ll = model.get_cost('ll_res')
        prediction = model.run(model.prediction['res'])
        keys = ['res', 'odds']
        datas = {}
        for key in keys:
            datas[key] = overtime.get_py_slice(i, 'test', key)
            if len(datas[key]) != len(prediction):
                print('ERROR')
        for j in range(len(prediction)):
            to_write = list(prediction[j]) + datas['odds'][j] + datas['res'][j]
            print(to_write)
            spamwriter.writerow(to_write)
        ll_mean += ll
        lls_mean += ll**2
        print(i, ll, '(time: ' + str(time.time() - t) + ')')

print('Mean: ', ll_mean/overtime.nb_slices)
print('Std_Dev: ', math.sqrt(lls_mean/overtime.nb_slices - (ll_mean/overtime.nb_slices)**2))


model.close()
